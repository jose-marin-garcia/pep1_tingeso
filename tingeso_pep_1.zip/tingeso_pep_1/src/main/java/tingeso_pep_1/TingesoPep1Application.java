package tingeso_pep_1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TingesoPep1Application {

	public static void main(String[] args) {
		SpringApplication.run(TingesoPep1Application.class, args);
	}

}
